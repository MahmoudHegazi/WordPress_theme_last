<?php get_header();
/*
* Template Name: Full Width page
*/



?>

<!-- Page Title
    ============================================= -->
<section id="page-title">
  <div class="container clearfix">
    <h1><?php
    // help us to get the post title
    // rewind function used to use the same query in diffrent location
    single_post_title(); ?></h1>
    <span><?php
    if( function_exists( 'the_subtitle' ) ) {
     the_subtitle();
}
     ?></span>
  </div>
</section><!-- #page-title end -->


    <!-- Content
    ============================================= -->
    <section id="content">

       <div class="content-wrap">




        <div class="container clearfix">

          <!-- Post Content
          ============================================= -->
          <div class="postcontent nobottommargin clearfix">
            <?php

                  while( have_posts() ) {
                    the_post();
                    global $post;
                    $author_id               =  $post->post_author;
                    $autor_url               =  get_author_posts_url($author_id);
                    ?>


                  </div><!-- .postcontent end -->

                    <?php
                  }

            ?>

        </div>

      </div>

    </section><!-- #content end -->

<?php get_footer(); ?>
