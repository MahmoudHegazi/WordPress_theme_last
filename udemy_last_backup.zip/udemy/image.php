<?php get_header(); ?>

    <!-- Content
    ============================================= -->
    <section id="content">

       <div class="content-wrap">


        <div class="container clearfix">

          <!-- Post Content
          ============================================= -->
          <div class="postcontent nobottommargin clearfix">
            <?php
              if( have_posts() ){
                  while( have_posts() ) {
                    the_post();
                    global $post;
                    $author_id               =  $post->post_author;
                    $autor_url               =  get_author_posts_url($author_id);
                    ?>

                    <div class="single-post nobottommargin">

                      <!-- Single Post
                                    ============================================= -->


                        <!-- Entry Title
                                        ============================================= -->
                        <div class="entry-title">
                          <h2><?php the_title(); ?></h2>
                        </div><!-- .entry-title end -->


                        <!-- Entry Content
                                        ============================================= -->
                        <div class="entry-content notopmargin">
                           <a href='<?php echo $post->guid; ?>'>Direct Download</a>
                           <br >
                           <img src="<?php echo $post->guid; ?>" class="img-responsive">
                           <?php
                           the_content();

                            ?>
                          <!-- Post Single - Content End -->





                        </div>
                      </div><!-- .entry end -->







                                   <div class="mpost clearfix">
                                     <?php
                                          if ( has_post_thumbnail() ) {

                                            ?>
                                            <div class="entry-image">
                                              <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail( 'thumbnail'); ?>
                                              </a>
                                            </div>





                                            <?php
                                          }


                                     ?>



                                   <?php
                             }
                          }
                          wp_reset_postdata();

                        ?>


                      </div>
                      <?php
                       // this will search for comments.php and excute it
                      if ( comments_open() || get_comments_number() ) {
                      comments_template();
                    }

                   ?>


                    </div>




          <!-- Sidebar
          ============================================= -->
          <?php get_sidebar(); ?>
<!-- .sidebar end -->

        </div>

      </div>

    </section><!-- #content end -->

<?php get_footer(); ?>
