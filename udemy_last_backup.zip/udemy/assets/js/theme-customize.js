/**
 * Created by test on 3/27/2017.
 */
(function($){
  // this function to update the search and cart using jQuery
  // to make improv,emts in preforemance
  // oh this is ajax not only javascript refresh the page without reload
    wp.customize( 'ju_header_show_search', function( value ) {
        value.bind(function(new_val) {
           if (new_val) {
             $("#top-search").show();
           } else {
             $("#top-search").hide();
           }
        });
    });

    wp.customize( 'ju_header_show_cart', function( value ) {
        value.bind(function(new_val) {
           if (new_val) {
             $("#top-cart").show();
           } else {
             $("#top-cart").hide();
           }
        });
    });
})(jQuery);
