<?php
  // oh this is ajax not only javascript refresh the page without reload
  // we use this to update the page with changes without reload the page using ajax
  // wordpress handle ajax part for us
function ju_customize_preview_init() {
  wp_enqueue_script(
      'ju_theme_customizer',
      get_theme_file_uri( '/assets/js/theme-customize.js' ),
      [ 'jquery', 'customize-preview' ],
      false,
      true
  );
}

 ?>
