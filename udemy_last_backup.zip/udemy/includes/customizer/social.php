<?php

// this function add new input to customize
// add settings will create data base value (very important)
// add setting will not create input it will just tell the wordpress
// about the setting and tell wordpress create  that in data base
function ju_social_customizer_section( $wp_customize ) {
  // create the setting the value is store to database

  // Facebook
  $wp_customize->add_setting( 'ju_facebook_handle', [
      'default'            =>        ''
  ]);

  // Twitter
  $wp_customize->add_setting( 'ju_twitter_handle', [
      'default'            =>        ''
  ]);

  // Instagram
  $wp_customize->add_setting( 'ju_insta_handle', [
      'default'            =>        ''
  ]);

  // Mobile
  $wp_customize->add_setting( 'ju_mobile_handle', [
      'default'            =>        ''
  ]);

  // mail
  $wp_customize->add_setting( 'ju_mail_handle', [
      'default'            =>        ''
  ]);

 //  create section the section that group controllers
 // we create the social section once only contains all inputs
  $wp_customize->add_section( 'ju_social_section', [
      'title'           =>  __( 'Udemy Social Settings', 'udemy' ),
      'priority'        =>  30,
      // we path the panel id to be container to that section create it
      // using add_panel in theme-customizer
      'panel'           =>  'udemy'  
  ]);

// add_control will not create database value it will create input filed
// create controller asgined under section  and control one setting

  // facebook
  $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'ju_social_facebook_input',
        array(
            'label'          => __( 'Facebook Handle', 'udemy' ),
            'section'        => 'ju_social_section',
            'settings'       => 'ju_facebook_handle',
            'type'           => 'text'
                  )
    ));

    // Twitter
    $wp_customize->add_control(new WP_Customize_Control(
          $wp_customize,
          'ju_social_twitter_input',
          array(
              'label'          => __( 'Twitter Handle', 'udemy' ),
              'section'        => 'ju_social_section',
              'settings'       => 'ju_twitter_handle',
              'type'           => 'text'
                    )
      ));

    // Instagram
    $wp_customize->add_control(new WP_Customize_Control(
            $wp_customize,
            'ju_social_insta_input',
            array(
                'label'          => __( 'Instagram Handle', 'udemy' ),
                'section'        => 'ju_social_section',
                'settings'       => 'ju_insta_handle',
                'type'           => 'text'
                      )
        ));

        // Mobile
        $wp_customize->add_control(new WP_Customize_Control(
                $wp_customize,
                'ju_social_mobile_input',
                array(
                    'label'          => __( 'Mobile Handle', 'udemy' ),
                    'section'        => 'ju_social_section',
                    'settings'       => 'ju_mobile_handle',
                    'type'           => 'te'
                          )
            ));

            // Mail
            $wp_customize->add_control(new WP_Customize_Control(
                    $wp_customize,
                    'ju_social_mail_input',
                    array(
                        'label'          => __( 'Mail Handle', 'udemy' ),
                        'section'        => 'ju_social_section',
                        'settings'       => 'ju_mail_handle',
                        'type'           => 'text'
                              )
                ));
}



?>
