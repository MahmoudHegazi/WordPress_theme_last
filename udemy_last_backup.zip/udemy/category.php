<?php get_header(); ?>


<!-- Page Title
    ============================================= -->
<section id="page-title">

  <div class="container clearfix">
    <h1><?php


// this function to edit the category and not make it appear
    add_filter( 'get_the_archive_title', function ($title) {
        if ( is_category() ) {
                $title = single_cat_title( 'Category: ', false );
            } elseif ( is_tag() ) {
                $title = single_tag_title( '', false );
            } elseif ( is_author() ) {
                $title = '<span class="vcard">' . get_the_author() . '</span>' ;
            } elseif ( is_tax() ) { //for custom post types
                $title = sprintf( __( '%1$s' ), single_term_title( '', false ) );
            } elseif (is_post_type_archive()) {
                $title = post_type_archive_title( '', false );
            }
        return $title;
    });

  the_archive_title();

     ?></h1><br
    <span><?php the_archive_description(); ?></span>
  </div>

</section><!-- #page-title end -->

    <!-- Content
    ============================================= -->
    <section id="content">

      <div class="content-wrap">



        <div class="container clearfix">

          <!-- Post Content
          ============================================= -->
          <div class="postcontent nobottommargin clearfix">

            <!-- Posts
            ============================================= -->
            <div id="posts">
              <?php
                 if ( have_posts() ) {
                     while ( have_posts() ) {
                       the_post();
                       // content-excerpt.php
                       get_template_part( 'partials/post/content-excerpt' );
                       // content-excerpt.php , if not found look for content.php
                       // get_template_part( 'partials/post/content', 'excerpt' );
                     }
                 }
              ?>


            </div><!-- #posts end -->

            <!-- Pagination
            ============================================= -->
            <div class="row mb-3">
              <div class="col-12">
                <?php
                    next_posts_link( '&larr; Older' );

                    previous_posts_link( 'Newer &rarr;' );

                ?>
                <!--
                <a href="#" class="btn btn-outline-secondary float-left">

                </a>
                <a href="#" class="btn btn-outline-dark float-right">

                </a> -->
              </div>
            </div>
            <!-- .pager end -->

          </div><!-- .postcontent end -->

          <!-- Sidebar
          ============================================= -->
          <?php get_sidebar(); ?>
<!-- .sidebar end -->

        </div>

      </div>

    </section><!-- #content end -->

<?php get_footer(); ?>
