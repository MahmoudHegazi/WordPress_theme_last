<?php get_header(); ?>


<!-- Page Title
    ============================================= -->
<section id="page-title">

  <div class="container clearfix">
<h2>
    <?php
    // this function remove the useles title and br 
    // this function to edit the category and not make it appear
    // Simply remove anything that looks like an archive title prefix ("Archive:", "Foo:", "Bar:").
    // Return an alternate title, without prefix, for every type used in the get_the_archive_title().
    add_filter('get_the_archive_title', function ($title) {
        if ( is_category() ) {
            $title = single_cat_title( '', false );
        } elseif ( is_tag() ) {
            $title = single_tag_title( '', false );
        } elseif ( is_author() ) {
            $title = '<span class="vcard">' . get_the_author() . '</span>';
        } elseif ( is_year() ) {
            $title = get_the_date( _x( 'Y', 'yearly archives date format' ) );
        } elseif ( is_month() ) {
            $title = get_the_date( _x( 'F Y', 'monthly archives date format' ) );
        } elseif ( is_day() ) {
            $title = get_the_date( _x( 'F j, Y', 'daily archives date format' ) );
        } elseif ( is_tax( 'post_format' ) ) {
            if ( is_tax( 'post_format', 'post-format-aside' ) ) {
                $title = _x( 'Asides', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {
                $title = _x( 'Galleries', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-image' ) ) {
                $title = _x( 'Images', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
                $title = _x( 'Videos', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {
                $title = _x( 'Quotes', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-link' ) ) {
                $title = _x( 'Links', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-status' ) ) {
                $title = _x( 'Statuses', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {
                $title = _x( 'Audio', 'post format archive title' );
            } elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {
                $title = _x( 'Chats', 'post format archive title' );
            }
        } elseif ( is_post_type_archive() ) {
            $title = post_type_archive_title( '', false );
        } elseif ( is_tax() ) {
            $title = single_term_title( '', false );
        } else {
            $title = __( 'Archives' );
        }
        return $title;
    });
?>

<?php
      the_archive_title();


     ?></h2>
    <span><?php
    if ( is_year() ) {
       ?> You're viewing a year archive  <?php
    } else if ( is_month() ) {
       ?> You're viewing a month archive <?php
    } else {
        ?> You're viewing a day archive <?php
    }

     ?>
   </span>
  </div>

</section><!-- #page-title end -->

    <!-- Content
    ============================================= -->
    <section id="content">

      <div class="content-wrap">



        <div class="container clearfix">

          <!-- Post Content
          ============================================= -->
          <div class="postcontent nobottommargin clearfix">

            <!-- Posts
            ============================================= -->
            <div id="posts">
              <?php
                 if ( have_posts() ) {
                     while ( have_posts() ) {
                       the_post();
                       // content-excerpt.php
                       get_template_part( 'partials/post/content-excerpt' );
                       // content-excerpt.php , if not found look for content.php
                       // get_template_part( 'partials/post/content', 'excerpt' );
                     }
                 }
              ?>


            </div><!-- #posts end -->

            <!-- Pagination
            ============================================= -->
            <div class="row mb-3">
              <div class="col-12">
                <?php
                    next_posts_link( '&larr; Older' );

                    previous_posts_link( 'Newer &rarr;' );

                ?>
                <!--
                <a href="#" class="btn btn-outline-secondary float-left">

                </a>
                <a href="#" class="btn btn-outline-dark float-right">

                </a> -->
              </div>
            </div>
            <!-- .pager end -->

          </div><!-- .postcontent end -->

          <!-- Sidebar
          ============================================= -->
          <?php get_sidebar(); ?>
<!-- .sidebar end -->

        </div>

      </div>

    </section><!-- #content end -->

<?php get_footer(); ?>
