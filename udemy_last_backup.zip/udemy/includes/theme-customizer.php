<?php

// this function defined in customeizer in soical file
// this hndle the social links in the header
// we add all customize calls here in order to see changes in cusotmize
function ju_customize_register( $wp_customize ){

  /* to check for id in $wp_customize which is huge object contain all editable data
   echo "<pre>";
   echo var_dump( $wp_customize );
   echo "</pre>";
   */
   // group my sections into panel 1.panel, 2.sections, 3.Controls
   // this make one button on customize page for all sections together

   // this method take the section id we can get it from using var_dump($wp_customize)
   // grap what u neeed and edit it
   // for controls (get_control method) , for settings (get_setting method)
   // for panel (get_pnael method )
   $wp_customize->get_section( 'title_tagline' )->title  =  'General';

   $wp_customize->add_panel( 'udemy', [
      'title'            => __( "Udemy", "udemy"),
      'description'      => '<p>Udemy Theme Settings </p>',
      'priority'         =>  160
   ]);
   // function handle social links
   ju_social_customizer_section($wp_customize);
   // function handle show search input
   ju_misc_customizer_section( $wp_customize );
}


 ?>
