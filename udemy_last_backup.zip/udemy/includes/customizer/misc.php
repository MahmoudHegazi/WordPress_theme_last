<?php
function ju_misc_customizer_section( $wp_customize ) {

  $wp_customize->add_setting( 'ju_header_show_search', [
    'default'          =>  'yes',
    'transport'        =>  'postMessage'
  ]);

  $wp_customize->add_setting( 'ju_header_show_cart', [
    'default'          =>  'yes',
    // default of transport is refresh _ refresh the page each value updated
    // postMessage we tell we are using JS to refelect the changes on the page
    'transport'        =>  'postMessage'
  ]);

  $wp_customize->add_setting( 'ju_footer_copyright_text', [
    'default'          =>  'Copyrights &copy; 2020 All Rights Reserved.',
  ]);

  $wp_customize->add_setting( 'ju_footer_tos_page', [
    'default'          =>  0,
  ]);

  $wp_customize->add_setting( 'ju_footer_privacy_page', [
    'default'          =>  0,
  ]);
  // set the colors setting add to database
  $wp_customize->add_setting( 'ju_read_more_color', [
        'default'            =>  '#1ABC9C'
    ]);

    // set the report add to database
    $wp_customize->add_setting( 'ju_report_file', [
          'default'            =>  ''
      ]);

  // add section
  $wp_customize->add_section( 'ju_misc_section', [
      'title'          =>  __( 'Udemy Misc Settings', 'udemy'),
      'priority'       =>  30,
      // we path the panel id to be container to that section create it
      // using add_panel in theme-customizer
      'panel'          => 'udemy'
  ]);


  $wp_customize->add_control( new WP_Customize_Control(
          $wp_customize,
          'ju_header_show_search_input',
          array(
              'label'          => __( 'Show Search Button in Header', 'udemy' ),
              'section'        => 'ju_misc_section',
              'settings'       => 'ju_header_show_search',
              'type'           => 'checkbox',
              'choices'        => [
                'yes'          => 'Yes'
                ]
            )
          ));
  $wp_customize->add_control( new WP_Customize_Control(
          $wp_customize,
          'ju_header_show_cart_input',
          array(
                'label'          => __( 'Show Cart Button in Header', 'udemy' ),
                'section'        => 'ju_misc_section',
                'settings'       => 'ju_header_show_cart',
                'type'           => 'checkbox',
                'choices'        => [
                  'yes'          => 'Yes'
                  ]
           )
          ));


  $wp_customize->add_control( new WP_Customize_Control(
          $wp_customize,
          'ju_footer_edit_copyright_input',
              array(
                  'label'          => __( 'Edit Copyrights text in Footer', 'udemy' ),
                  'section'        => 'ju_misc_section',
                  'settings'       => 'ju_footer_copyright_text',
                  'type'           => 'text'
                   )
                  ));

  $wp_customize->add_control( new WP_Customize_Control(
          $wp_customize,
          'ju_footer_tos_page_input',
          array(
                'label'          => __( 'Footer tos page', 'udemy' ),
                'section'        => 'ju_misc_section',
                'settings'       => 'ju_footer_tos_page',
                'type'           => 'dropdown-pages'
                      )
                      ));

    $wp_customize->add_control( new WP_Customize_Control(
            $wp_customize,
            'ju_footer_privacy_page_input',
            array(
                  'label'          => __( 'Footer Privacy Policy Page', 'udemy' ),
                  'section'        => 'ju_misc_section',
                  'settings'       => 'ju_footer_privacy_page',
                  'type'           => 'dropdown-pages'
                        )
                        ));
  $wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'ju_read_more_color_input',
    array(
        'label'      => __( 'Read more link Color', 'udemy' ),
        'section'    => 'ju_misc_section',
        'settings'   => 'ju_read_more_color',
      )
    )
  );

  // here we use ne class upload control not customize control
  $wp_customize->add_control(new WP_Customize_Upload_Control(
    $wp_customize,
    'ju_report_file_input',
    array(
        'label'      => __( 'File Report', 'udemy' ),
        'section'    => 'ju_misc_section',
        'settings'   => 'ju_report_file',
     )
   )
  );
}
 ?>
